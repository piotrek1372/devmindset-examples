device = input("Urządzenie: ")
quantity = int(input("Liczba części: "))
part_price = float(input("Cena jednej części (zł): "))
hours = float(input("Czas pracy (h): "))
hourly_rate = float(input("Stawka godzinowa (zł): "))

parts_cost = quantity * part_price
labor_cost = hours * hourly_rate
total = parts_cost + labor_cost

print(f"Urządzenie: {device}")
print(f"Części: {parts_cost:.2f} zł")
print(f"Robocizna: {labor_cost:.2f} zł")
print(f"Razem: {total:.2f} zł")
