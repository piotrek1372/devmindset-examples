quantity_text = input("Liczba części: ")
quantity = int(quantity_text)
print(quantity + 1)
