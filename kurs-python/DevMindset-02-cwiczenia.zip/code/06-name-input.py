device = input("Urządzenie: ")
print(device)
