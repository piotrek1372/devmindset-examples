device = "Laptop
print(device)
