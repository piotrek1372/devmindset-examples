device = "Laptop"
total = 219.0
print(f"Urządzenie: {device}")
print(f"Razem: {total:.2f} zł")
