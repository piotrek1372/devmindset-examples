print("Kalkulator naprawy")
