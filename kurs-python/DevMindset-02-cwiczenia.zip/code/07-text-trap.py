parts = input("Koszt części: ")
labor = input("Koszt pracy: ")
print(parts + labor)
