device = "Laptop"
print(device)
device = "Telefon"
print(device)
