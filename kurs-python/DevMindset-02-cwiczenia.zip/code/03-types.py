device = "Laptop"
quantity = 2
part_price = 49.50
print(type(device))
print(type(quantity))
print(type(part_price))
