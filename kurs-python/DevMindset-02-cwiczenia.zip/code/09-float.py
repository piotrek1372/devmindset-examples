price_text = input("Cena części (np. 49.50): ")
part_price = float(price_text)
print(part_price * 2)
