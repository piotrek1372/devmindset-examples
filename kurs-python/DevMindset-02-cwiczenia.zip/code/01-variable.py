device = "Laptop"
print(device)
