device = "Laptop"
print(devcie)
