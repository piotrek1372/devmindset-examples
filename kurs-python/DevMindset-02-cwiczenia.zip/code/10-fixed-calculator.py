quantity = 2
part_price = 49.50
hours = 1.5
hourly_rate = 80.0
parts_cost = quantity * part_price
labor_cost = hours * hourly_rate
total = parts_cost + labor_cost
print(total)
