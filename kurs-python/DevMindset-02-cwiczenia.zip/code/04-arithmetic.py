quantity = 2
part_price = 49.50
parts_cost = quantity * part_price
print(parts_cost)
