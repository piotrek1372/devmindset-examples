# Kontrola twierdzeń
Zweryfikowano 2026-10-06 w oficjalnej dokumentacji Pythona linii 3.12. Wykonanie pozostaje na 3.12.14; strona dokumentacji pokazuje 3.12.15. Nie aktualizowano interpretera.
| Twierdzenie | Źródło | Dowód wykonania |
|---|---|---|
| Przypisanie i ponowne przypisanie wiążą nazwę z wartością | https://docs.python.org/3.12/tutorial/introduction.html#numbers | 01-variable.json, 02-change.json |
| Reguły nazw i wielkość liter | https://docs.python.org/3.12/reference/lexical_analysis.html#identifiers | 13-name-error.json; porównanie identyfikatorów w źródle |
| int, float i str to różne typy | https://docs.python.org/3.12/library/stdtypes.html | 03-types.json |
| Operatory i pierwszeństwo działań; / daje float w tych przykładach | https://docs.python.org/3.12/tutorial/introduction.html#numbers | 04-arithmetic.json, 05-operators.json |
| input zwraca tekst, int/float wykonują konwersję | https://docs.python.org/3.12/library/functions.html#input oraz #int i #float | 06-name-input.json, 07-text-trap.json, 08-int.json, 09-float.json |
| Plus łączy teksty | https://docs.python.org/3.12/tutorial/introduction.html#text | 07-text-trap.json |
| F-string podstawia wartości i obsługuje specyfikację formatu | https://docs.python.org/3.12/tutorial/inputoutput.html#formatted-string-literals | 11-format.json, 12-calculator.json |
| Nie każdy ułamek dziesiętny ma dokładną reprezentację float | https://docs.python.org/3.12/tutorial/floatingpoint.html | właściwość reprezentacji; nie prezentujemy nieuruchomionego dodatkowego przykładu |
| ValueError, NameError i SyntaxError mają różne przyczyny | https://docs.python.org/3.12/tutorial/errors.html | case-bad-number.json, 13-name-error.json, 14-syntax-error.json |
Wszystkie nazwy logów odnoszą się do logs/. Narracja, scenariusz i przykłady są autorskie. Analogia etykiety jest zaznaczona jako pomocnicza.
