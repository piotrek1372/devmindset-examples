# Samodzielna próba — bez rozwiązania
## Próby w trakcie filmu
1. Zmień nazwę urządzenia z Laptop na Monitor; przewidź wynik przed uruchomieniem.
2. Usuń drugie przypisanie w 02-change.py. Jakie dwa komunikaty zobaczysz?
3. Oblicz koszt trzech części po 49.50 zł. Przewidź i sprawdź.
4. W 09-float.py podaj 12.75. Przewidź koszt dwóch części.
5. Uruchom pełny kalkulator dla jednej części po 20 zł, dwóch godzin i stawki 50 zł/h. Sprawdź wszystkie składniki, nie tylko sumę.
## Główne zadanie: rabat na całą naprawę
Pracuj na kopii code/12-calculator.py. Dodaj pytanie o rabat kwotowy na całą naprawę; rabat może być ułamkowy. Pomniejsz sumę i pokaż rabat z dwoma miejscami po kropce. Nie odejmuj rabatu osobno od części i osobno od pracy.
Na tym etapie przyjmij poprawne dane: wartości nieujemne, liczba części całkowita, rabat nie większy niż koszt naprawy. W ułamkach używaj kropki.
Przypadek A: Laptop; 2 części; cena 49.50; 1.5 h; stawka 80; rabat 20. Oczekiwana kwota po rabacie: 199.00 zł.
Przypadek B: te same dane; rabat 0. Oczekiwana kwota: 219.00 zł.
Przypadek C: jedna część za 20, 2 h po 50, rabat 10. Oczekiwana kwota: 110.00 zł.
## Kiedy uznasz zadanie za wykonane
Potrafisz wskazać wejście, konwersje, obliczenia i wyjście. Wyniki zgadzają się z prognozą dla wszystkich trzech prób. Potrafisz wyjaśnić, dlaczego input wymaga konwersji przed obliczeniem.
Nie traktujemy obejrzenia filmu jako potwierdzenia opanowania. Najpierw samodzielna próba; dopiero potem hints.md i solutions.md.
