# Rozwiązania — po samodzielnej próbie
Główne rozwiązanie: code/15-solution-discount.py. Rzeczywisty wynik wykonania: logs/15-solution-discount.json.
Dodana linia odbiera discount przez float(input(...)). Total obliczamy jako parts_cost + labor_cost - discount. Nowy print pokazuje rabat; reszta wzoru nie zmienia się.
Próby w trakcie filmu: 1. Monitor. 2. Laptop dwa razy. 3. 148.50 zł. 4. 25.5 (w wyświetleniu kwotowym 25.50). 5. Części 20, praca 100, razem 120.
Brak obsługi niepoprawnych danych jest świadomym ograniczeniem tego etapu; nie zaliczaj przypadkowego wyniku ujemnego jako poprawnej wyceny.
