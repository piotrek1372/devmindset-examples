# Podpowiedzi — czytaj stopniowo
1. Nową odpowiedź pobierz w tej części kodu, która zbiera dane. Wybierz nazwę opisującą rabat.
2. Input zwraca tekst. Rabat może mieć ułamek, więc potrzebujesz tej samej konwersji co dla ceny.
3. Rabat dotyczy całej naprawy. Wykorzystaj go w obliczeniu total, po zsumowaniu obu kosztów.
4. Do pokazania rabatu użyj wzoru komunikatu z kwotą części. Wyświetlenie nie powinno zmieniać obliczenia.
5. Wynik większy od 219 oznacza prawdopodobnie dodanie zamiast odjęcia; wynik 179 przy rabacie 20 oznacza prawdopodobnie podwójne odjęcie.
