total = 219
if total = 219:
    print("Koszt zgodny")
