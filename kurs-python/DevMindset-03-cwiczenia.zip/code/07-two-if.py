total = 150
if total < 200:
    print("Mała naprawa")
if total < 500:
    print("Średnia naprawa")
