total = float(input("Koszt: "))
budget = 200
if total > budget:
    print("Koszt przekracza budżet")
    print("Porozmawiaj z klientem")
print("Koniec sprawdzenia")
