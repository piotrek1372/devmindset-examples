total = 219
budget = 200
print(total <= budget)
print(total > budget)
print(type(total <= budget))
