device = input("Urządzenie: ")
quantity = int(input("Liczba części: "))
part_price = float(input("Cena części (kropka): "))
hours = float(input("Godziny: "))
hourly_rate = float(input("Stawka: "))
discount = float(input("Rabat kwotowy: "))
budget = float(input("Budżet: "))

if quantity < 0 or part_price < 0:
    print("Błąd: liczba części i cena muszą być nieujemne")
elif hours < 0 or hourly_rate < 0:
    print("Błąd: czas i stawka muszą być nieujemne")
elif budget < 0:
    print("Błąd: budżet musi być nieujemny")
else:
    parts_cost = quantity * part_price
    labor_cost = hours * hourly_rate
    subtotal = parts_cost + labor_cost

    if discount < 0 or discount > subtotal:
        print("Błąd: rabat poza zakresem")
    else:
        total = subtotal - discount
        print(f"Urządzenie: {device}")
        print(f"Do zapłaty: {total:.2f} zł")
        if total <= budget:
            print("Koszt mieści się w budżecie")
        else:
            print("Koszt przekracza budżet")
