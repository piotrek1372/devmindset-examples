total = float(input("Koszt: "))
if total < 200:
    print("Mała naprawa")
elif total < 500:
    print("Średnia naprawa")
else:
    print("Duża naprawa")
