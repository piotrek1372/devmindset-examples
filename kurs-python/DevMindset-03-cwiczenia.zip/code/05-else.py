total = float(input("Koszt: "))
budget = 200
if total <= budget:
    print("Koszt mieści się w budżecie")
else:
    print("Koszt przekracza budżet")
