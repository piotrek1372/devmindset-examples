total = 219
if total > 200:
print("Przekroczony budżet")
