quantity = int(input("Liczba części: "))
hours = float(input("Godziny: "))
invalid_data = quantity < 0 or hours < 0
print(invalid_data)
