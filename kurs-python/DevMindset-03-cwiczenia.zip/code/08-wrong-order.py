total = 150
if total < 500:
    print("Średnia naprawa")
elif total < 200:
    print("Mała naprawa")
