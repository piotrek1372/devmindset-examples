answer = input("Zgoda klienta (tak/nie): ")
approved = answer == "tak"
if not approved:
    print("Wstrzymaj rozpoczęcie naprawy")
else:
    print("Zgoda zapisana")
