total = 150
budget = 200
if total > budget:
    print("Koszt przekracza budżet")
print("Poproś o zgodę na dopłatę")
