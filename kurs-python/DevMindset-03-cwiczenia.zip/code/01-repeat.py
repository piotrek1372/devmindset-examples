parts_cost = 2 * 49.50
labor_cost = 1.5 * 80
total = parts_cost + labor_cost
print(f"Koszt: {total:.2f} zł")
