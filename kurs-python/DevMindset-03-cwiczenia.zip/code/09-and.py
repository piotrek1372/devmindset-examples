discount = float(input("Rabat: "))
total = 219
valid_discount = discount >= 0 and discount <= total
print(valid_discount)
