# Źródła i sprawdzenie twierdzeń

Dokumentacja Python 3.12, sprawdzona 2026-10-09:
- https://docs.python.org/3.12/tutorial/controlflow.html — if/elif/else, wybór gałęzi i kolejność. Własne przykłady 04–08, rzeczywiste wyniki w logs i testach progów 199/200/499/500.
- https://docs.python.org/3.12/library/stdtypes.html#boolean-operations-and-or-not — bool, porównania, and/or/not. Własne przykłady 02,03,09–11. Operandy w odcinku są wartościami bool uzyskanymi z porównań; nie twierdzimy, że and/or zawsze zwracają bool dla dowolnych obiektów.
- https://docs.fish.audio/features/text-to-speech — struktura generowania narracji. Nie potwierdza dostępności darmowego modelu na konkretnym koncie. Skrypty Fish przetestowano wyłącznie lokalnie bez żądania API.

Materiał i przykłady napisano samodzielnie. Nie jest to kopia dokumentacji. Pełne źródła i hash przy wykonaniu pozwalają sprawdzić zgodność obrazu z programem.
