# Ćwiczenia

1. Przed uruchomieniem 06-elif.py przewidź kategorię dla 199, 200, 499 i 500. Dlaczego 200 nie jest małą naprawą?
2. Uruchom 07-two-if.py i 08-wrong-order.py dla 150. Wyjaśnij osobno problem niezależnych if oraz kolejności warunków.
3. W kalkulatorze sprawdź rabat -1, 0, 219 i 220 przy cenie przed rabatem 219. Tylko wartości z przedziału domkniętego 0–219 są poprawne.
4. Popraw 15-repair-bug.py. Dla 150 żaden komunikat ostrzegawczy nie powinien się pojawić. Wskazówka: sprawdź wcięcie ostatniej linii. Rozwiązanie: 16-repair-fixed.py.
5. Rozbuduj 14-full.py: koszt mniejszy od budżetu → „Pozostał zapas”, równy → „Dokładnie budżet”, większy → „Potrzebna dopłata”. Nie usuwaj wcześniejszej walidacji. Dla kosztu 199 przetestuj budżet 198, 199, 200. Wskazówka: trzy rozłączne gałęzie. Rozwiązanie w 17-solution.py otwórz dopiero po próbie.

Warunek przejścia: samodzielnie wykonać zadanie 5, przewidzieć wszystkie trzy wyniki i wyjaśnić różnicę między = a ==. Obejrzenie filmu nie potwierdza opanowania materiału.
