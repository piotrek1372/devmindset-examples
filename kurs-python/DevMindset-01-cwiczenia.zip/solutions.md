# Przykładowe rozwiązanie — po własnej próbie
```python
print("Hej, Piotrek!")
```
Wynik: Hej, Piotrek! Cudzysłowy w tym przykładzie określają tekst w kodzie.
