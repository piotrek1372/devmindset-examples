# Twoja próba
Zmień komunikat na własne powitanie. Przewidź wynik, zapisz plik, uruchom i porównaj. Wyjaśnij, dlaczego cudzysłów nie pojawia się w wyniku.
