# Uruchomienie
Sprawdzenia wykonano w środowisku A, w venv. Interpreter opisano w environment.json. Brak dodatkowych bibliotek.
W katalogu lekcji w kontenerze:
```bash
.venv/bin/python code/01_hello.py
.venv/bin/python code/02_final.py
.venv/bin/python code/error_demo.py
```
Ostatnie polecenie celowo kończy się błędem składni. Polecenie nie zmienia komputera ucznia.
Po pobraniu materiałów trzeba utworzyć nowe venv właściwym lokalnym interpreterem; wirtualnego środowiska kontenera nie dołączono. Instrukcja instalacji i obsługi edytora zależy od audytu komputera ucznia.
