# Źródła i sprawdzenie twierdzeń
Weryfikacja 2026-10-05; interpreter kontenerowy zapisany w environment.json.
- print wypisuje przekazany tekst: https://docs.python.org/3.12/library/functions.html#print ; logi 01 i 02.
- Cudzysłowy określają literał tekstowy: https://docs.python.org/3.12/tutorial/introduction.html#text ; logi 01 i 02.
- Niedomknięty cudzysłów: rzeczywisty SyntaxError w assets/error_demo-run.json.
- Polecenia lokalne oraz kliknięcia w edytorze: niezweryfikowane, do audytu środowiska B.
