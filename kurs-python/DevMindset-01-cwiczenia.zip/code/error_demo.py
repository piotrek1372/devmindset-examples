print("Cześć, Python!)
