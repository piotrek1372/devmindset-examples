print("Cześć!")
