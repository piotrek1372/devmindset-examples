print("Cześć, Python!")
