devices = ["laptop", "telefon"]
devices.append("radio")
print(devices)
print(len(devices))
