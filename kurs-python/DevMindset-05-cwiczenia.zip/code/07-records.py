jobs = [
    {"device": "laptop", "cost": 199.0},
    {"device": "telefon", "cost": 80.0},
]
print(jobs[1]["device"])
print(len(jobs))
