devices = ["laptop", "telefon", "radio"]
for device in devices:
    print(device)
print("Liczba:", len(devices))
