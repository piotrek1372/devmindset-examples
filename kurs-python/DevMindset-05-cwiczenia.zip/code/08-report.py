jobs = [
    {"device": "laptop", "cost": 199.0},
    {"device": "telefon", "cost": 80.0},
]
total = 0
for job in jobs:
    device = job["device"]
    cost = job["cost"]
    print(f"{device}: {cost:.2f} zł")
    total = total + cost
print(f"Suma: {total:.2f} zł")
