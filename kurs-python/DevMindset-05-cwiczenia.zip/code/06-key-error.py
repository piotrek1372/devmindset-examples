job = {"device": "laptop", "cost": 199.0}
print(job["price"])
