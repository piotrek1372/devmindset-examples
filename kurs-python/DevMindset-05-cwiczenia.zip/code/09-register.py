jobs = []
while True:
    device = input("Urządzenie lub koniec: ")
    if device == "koniec":
        break
    cost = float(input("Koszt: "))
    if cost < 0:
        print("Odrzucono ujemny koszt")
        continue
    job = {"device": device, "cost": cost}
    jobs.append(job)
total = 0
for job in jobs:
    device = job["device"]
    cost = job["cost"]
    print(f"{device}: {cost:.2f} zł")
    total = total + cost
print("Przyjęto:", len(jobs))
print(f"Suma: {total:.2f} zł")
