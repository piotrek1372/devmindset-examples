devices = ["laptop", "telefon", "radio"]
print(devices[0])
print(devices[2])
print(len(devices))
