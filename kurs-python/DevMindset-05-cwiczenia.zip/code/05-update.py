job = {"device": "laptop", "cost": 199.0}
job["cost"] = 180.0
job["status"] = "nowe"
print(job["cost"])
print(job["status"])
