jobs = [
    {"device": "laptop", "cost": 199.0},
    {"device": "telefon", "cost": 80.0},
    {"device": "radio", "cost": 100.0},
]
limit = 100.0
count = 0
for job in jobs:
    # Pokaż i policz tylko koszt większy od limitu.
    print(job["device"])
print("Powyżej limitu:", count)
