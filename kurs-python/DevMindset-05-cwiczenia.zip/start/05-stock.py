# Dane startowe; dopisz samodzielnie raport braków.
stock = [
    {"name": "kabel", "quantity": 2},
    {"name": "zasilacz", "quantity": 5},
    {"name": "śrubka", "quantity": 0},
]
minimum = 3
