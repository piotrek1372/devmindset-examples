total = 0
for number in range(3):
    cost = float(input("Koszt: "))
    total = total + cost
print(total)
