devices = ["laptop", "telefon"]
print(devices[len(devices)])
