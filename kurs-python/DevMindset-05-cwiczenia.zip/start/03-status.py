job = {"device": "laptop", "cost": 199.0}
status = input("Status: ")
# Dopisz status do job i pokaż pole ze słownika.
print(job["device"])
