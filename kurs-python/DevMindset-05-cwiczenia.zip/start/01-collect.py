devices = []
for number in range(2):
    device = input("Urządzenie: ")
    # Zachowaj urządzenie w liście.
print(devices)
print(len(devices))
