# Omówienia — otwórz po własnej próbie

Kod: osobne pliki w `solutions/`; nazwy odpowiadają plikom startowym. Uruchamiaj np. `python3 solutions/02-last.py`.

0. Continue musi znaleźć się po odczycie kosztu i przed dodaniem do sumy. Zero pozostaje poprawne.
1. Lista jest tworzona raz, append wykonuje się dla każdego pobranego urządzenia. Powtarzające się nazwy pozostają osobnymi wpisami.
2. Warunek długości jest przed odczytem, a ostatni nieujemny indeks to len(devices)-1. Pusta lista nigdy nie jest indeksowana.
3. Odpowiedź trafia do job["status"], potem jest stamtąd odczytywana. Format danych nie jest wymuszany automatycznie przez słownik.
4. Warunek `>` obejmuje print i zwiększenie licznika. `>=` nie spełnia wymagania granicznego. Lista oryginalna nie jest usuwana ani filtrowana w miejscu.
5. Raport magazynu zmienia zarówno warunek (poniżej minimum), jak i obliczenie (ile brakuje). Licznik opisuje liczbę produktów, a nie sztuk. To zadanie transferowe, nie zmiana nazw w kalkulatorze.

Rozszerzenie: zainicjalizuj osobny akumulator sztuk przed pętlą; w gałęzi braków dodawaj do niego missing; wyświetl po pętli. Dla minimum 3 i danych oryginalnych wynik 4, dla pustej listy 0.

P1: laptop / radio / 3. P2: telefon / 2; zmiana wyłącznie kosztu nie wpływa na odczyt device i długości listy.

Nie zaznaczaj „opanowane” tylko dlatego, że uruchomiłeś te pliki. Wróć do startu, wykonaj własną zmianę i wyjaśnij decyzję o wcięciu.
