# Ćwiczenia — bez kodu rozwiązań

Uruchamiaj z katalogu pakietu: `python3 start/01-collect.py` (zmień nazwę dla zadania). Sprawdzono Python 3.12.14. Windows: `py -3 start/01-collect.py`, jeśli używasz launchera. Dane wpisuj po jednym wierszu. Zachowaj osobną kopię pliku przed zmianą. Wartości pieniężne z kropką.

## Przypomnienie — około 2 min
`start/00-recall.py`: pomijaj ujemne koszty podczas sumowania trzech wpisów. Próby: 10, -5, 20 → 30; 0, 0, 0 → 0. Użyj pojęć z odcinka 4. Jeżeli utkniesz, zanotuj brak i wróć do omówienia, zamiast zgadywać kolekcje.

## 1. Zachowaj dwa zgłoszenia — około 3 min
`start/01-collect.py`: dopisz oba wpisy użytkownika do listy. Nie wpisuj danych na sztywno. Próby: laptop, telefon → lista dwóch nazw i długość 2; radio, radio → dwa radia i długość 2. Gotowe: oba wpisy pozostają w kolejności, także gdy nazwy są identyczne.

## 2. Napraw ostatni element — około 4 min
`start/02-last.py`: usuń przyczynę IndexError, wypisuj ostatni element niezależnie od długości. Pusta lista ma wypisać `Brak urządzeń`. Próby: laptop/telefon → telefon; pusta lista → komunikat. Dodatkowo jedna nazwa radio → radio. Nie wpisuj stałego indeksu dla konkretnego zestawu.

## 3. Status w zgłoszeniu — około 3 min
`start/03-status.py`: zapisz wpisany status w słowniku job i wypisz go przez odczyt słownika. Zachowaj istniejące pola. Próby wejścia: nowe → nowe; gotowe → gotowe. Samo wypisanie zmiennej status nie spełnia celu.

## 4. Raport powyżej limitu — około 4 min
`start/04-filter.py`: pokazuj i licz tylko wpisy z kosztem ściśle większym od limitu. Nie zmieniaj zawartości jobs. Próby: limit 100 → laptop i licznik 1; limit 199 → żadna nazwa, licznik 0. Radio za 100 sprawdza równość z granicą.

## Projekt po filmie — magazyn, 10–20 min
`start/05-stock.py`: dla każdego produktu poniżej minimum wypisz nazwę oraz liczbę brakujących sztuk. Policz produkty wymagające uzupełnienia. Produkt równy minimum pomijaj. Nie usuwaj oryginalnych danych.

Próba A: minimum 3; kabel 2, zasilacz 5, śrubka 0 → kabel: dokup 1; śrubka: dokup 3; pozycje do uzupełnienia: 2.

Próba B: ustaw ilości 3, 5, 3 → brak nazw, licznik 0. Próba graniczna: stock = [] → licznik 0.

Gotowe: próby przechodzą; wyjaśniasz jedną decyzję o wcięciu/inicjalizacji; bez rozwiązania zmieniasz minimum na 5 i przewidujesz nowy raport. Dla oryginalnych ilości dokup: kabel 3, śrubka 5; zasilacz pominięty.

Rozszerzenie opcjonalne: oblicz łączną liczbę sztuk do kupienia, nie tylko liczbę produktów. Dla oryginalnych danych i minimum 3: 4 sztuki; dla pustych danych: 0. Nie dodawaj bibliotek.

Wskazówki: `hints.md`. Rozwiązania: osobny katalog `solutions/` i `solutions.md`; otwórz po próbie. Zapisz wynik oraz wykorzystaną pomoc w `practice-log.csv`.
