# Uruchomienie

Rozpakuj pakiet, otwórz terminal w jego katalogu. Potrzebny Python 3; sprawdzono 3.12.14. Bez zewnętrznych bibliotek dla ćwiczeń. `python3 --version`, następnie `python3 start/01-collect.py` albo `python3 code/09-register.py`. Na Windows z launcherem: `py -3 code/09-register.py`.

Rejestr: wpisz kolejno laptop, 199, telefon, 80, koniec (każde Enter). Oczekiwane dwie pozycje i suma 279.00 zł. Koniec wpisane na początku daje licznik i sumę zero. Ujemny koszt odrzuca bieżące zgłoszenie. Dane: zwykłe skończone liczby z kropką. abc wywoła ValueError; jego obsługa poza lekcją. Dane nie są trwale zapisywane.

Pełny kalkulator: `python3 code/10-calculator-history.py`. Laptop: 2 części, 49.5 za część, 1.5 godziny, stawka 80, rabat 20, budżet 200; telefon: 0, 0, 1, 80, 0, 100; potem koniec. Wyniki 199 i 80, suma 279.

Produkcja (nie jest materiałem wymaganym od widza): `python3 -m venv .venv`, następnie `python3 tests/verify.py`. Renderer wymaga Pillow, FFmpeg i czcionki DejaVu Sans Mono: `python3 render_lesson.py replay.json exports/DevMindset-Python-05-bez-audio.mp4`. Bez audio jest to jawnie oznaczona niema próba, a nie finalny odcinek.
