# Wskazówki stopniowane — czytaj jedną na raz

## Przypomnienie
1. Kiedy ujemny koszt trafia do dodawania?
2. Sprawdź go przed sumowaniem; użyj continue w warunku.

## Zadanie 1
1. Sama zmienna device jest nadpisywana w każdym obrocie.
2. Potrzebujesz operacji dodawania do istniejącej listy.
3. Append wykonuj po input, wewnątrz for. Listę utwórz raz przed pętlą.

## Zadanie 2
1. Dwa elementy mają indeksy zero i jeden.
2. Ostatni nieujemny indeks to długość minus jeden.
3. Najpierw sprawdź długość. Dopiero w gałęzi dla niepustej listy odczytuj element; else wyświetla komunikat.

## Zadanie 3
1. Odpowiedź musi stać się wartością pola job, nie tylko osobną zmienną.
2. Klucz ma być tekstem `status`.
3. Przypisz do tego pola po pobraniu danych; wypisz odczyt tego samego klucza.

## Zadanie 4
1. Co znaczy „ściśle większy”? Co z kosztem równym limitowi?
2. Porównuj job["cost"] z limit.
3. Wypisanie nazwy i zwiększenie count muszą mieć to samo wcięcie wewnątrz warunku. Count zaczyna się od 0 przed for.

## Projekt magazynu
1. Każdy element listy jest opisem jednego produktu. Czego potrzebujesz z tego opisu?
2. Porównaj quantity z minimum; brak to różnica między minimum a ilością.
3. Licznik produktów zwiększaj tylko dla braków. Łączna liczba sztuk w rozszerzeniu to inny akumulator niż licznik produktów.
