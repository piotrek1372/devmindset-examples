# Źródła i kontrola twierdzeń — 2026-10-16

Źródło zasad: dołączony `project-sources(1).md`, kopia `project-standard.md`; aktualne skille python-video-academy, pva-course-planner, pva-code-replay i practice-standard.md przeczytane 16.10.2026. Nie kopiujemy rozdziałów dokumentacji; narracja i zadania są autorskie.

| Sprawdzona teza | Oficjalne źródło Python 3.12 | Nasz dowód |
|---|---|---|
| Lista jest indeksowana od zera; można ją zmieniać | https://docs.python.org/3.12/tutorial/introduction.html#lists | logs/list.json, last.json, index-error.json |
| append dodaje element; len liczy elementy | https://docs.python.org/3.12/tutorial/datastructures.html#more-on-lists i https://docs.python.org/3.12/library/functions.html#len | append.json, collect.json, collect-repeat.json |
| for przechodzi po elementach w kolejności | https://docs.python.org/3.12/tutorial/controlflow.html#for-statements | loop.json, report.json |
| Słownik wiąże klucz z wartością; przypisanie zmienia/dodaje pole; brak klucza to KeyError | https://docs.python.org/3.12/tutorial/datastructures.html#dictionaries | dict.json, update.json, key-error.json |
| Lista może przechowywać słowniki; odczyt złożony wybiera element i pole | https://docs.python.org/3.12/library/stdtypes.html#mapping-types-dict | records.json, register.json |
| Niepusta lista wymagana przy odczycie ostatniego elementu | https://docs.python.org/3.12/library/stdtypes.html#sequence-types-list-tuple-range | last-empty.json, last-single.json |

Dokumentacja linii 3.12 pokazuje 3.12.15; rzeczywisty interpreter wykonania: 3.12.14. Źródła otwarto 16.10.2026. Pełne stdout/stderr i hashe kodu w logs. Próby ze zmienionymi danymi mają własne pliki w tests/cases.

Zasady PRIMM i przypominania zaczerpnięto z dostarczonego standardu wraz z jego ograniczeniami. 4 przystanki i 2 prognozy to progi redakcyjne projektu, nie udowodnione optimum naukowe. Nie przeprowadzono badania skuteczności lekcji.

API Fish: https://docs.fish.audio/api-reference/endpoint/openapi-v1/text-to-speech — 16.10.2026 dokumentuje model s2.1-pro-free, references, prosody.speed i temperature. Zmienność temperature nie gwarantuje energiczności głosu; wariant musi zostać wybrany przez odsłuch. Brak integracji/klucza w tym zadaniu; nie wykonano żądań audio. Nie potwierdzono limitu konkretnego konta.
