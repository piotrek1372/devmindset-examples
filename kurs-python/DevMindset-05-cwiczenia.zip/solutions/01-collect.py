devices = []
for number in range(2):
    device = input("Urządzenie: ")
    devices.append(device)
print(devices)
print(len(devices))
