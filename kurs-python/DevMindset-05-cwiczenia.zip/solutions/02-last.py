devices = ["laptop", "telefon"]
if len(devices) > 0:
    print(devices[len(devices) - 1])
else:
    print("Brak urządzeń")
