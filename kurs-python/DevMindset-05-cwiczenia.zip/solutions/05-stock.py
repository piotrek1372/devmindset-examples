stock = [
    {"name": "kabel", "quantity": 2},
    {"name": "zasilacz", "quantity": 5},
    {"name": "śrubka", "quantity": 0},
]
minimum = 3
count = 0
for item in stock:
    if item["quantity"] < minimum:
        name = item["name"]
        missing = minimum - item["quantity"]
        print(f"{name}: dokup {missing}")
        count = count + 1
print("Pozycje do uzupełnienia:", count)
