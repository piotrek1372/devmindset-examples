total = 0
for number in range(3):
    cost = float(input("Koszt: "))
    if cost < 0:
        continue
    total = total + cost
print(total)
