jobs = [
    {"device": "laptop", "cost": 199.0},
    {"device": "telefon", "cost": 80.0},
    {"device": "radio", "cost": 100.0},
]
limit = 100.0
count = 0
for job in jobs:
    if job["cost"] > limit:
        print(job["device"])
        count = count + 1
print("Powyżej limitu:", count)
