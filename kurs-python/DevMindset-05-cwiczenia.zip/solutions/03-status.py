job = {"device": "laptop", "cost": 199.0}
status = input("Status: ")
job["status"] = status
print(job["device"])
print(job["status"])
