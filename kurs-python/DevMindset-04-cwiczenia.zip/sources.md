# Kontrola twierdzeń — 2026-10-12

Python 3.12, dokumentacja oficjalna:
- https://docs.python.org/3.12/reference/compound_stmts.html#the-while-statement — while sprawdza warunek przed blokiem i może nie wejść do niego ani razu. Dowód: 02-while.py, 03-zero.py; sceny S03–S06 i testy.
- https://docs.python.org/3.12/tutorial/controlflow.html — for pobiera kolejne elementy, range wyłącza granicę końcową i pozwala określić krok; break opuszcza najbliższą pętlę, continue przechodzi do następnego obrotu. Dowód: własne przykłady 05–09 i 13–14, rzeczywiste stdout w logs i testach.

Sposób sumowania i reguły kalkulatora są autorskimi zadaniami; ich wyniki potwierdzają wykonania tests/results.json. Brak postępu w 04-stuck.py: przerwanie procesu po limicie, zapisane jako timeout_terminated, a nie wymyślony komunikat Pythona.

Nagranie Fish: wykorzystanie przygotowanego wcześniej lokalnego workflow. Nie potwierdzono w tej sesji dostępności modelu s2.1-pro-free na koncie; skrypt nie przełącza się na model płatny. Test MessagePack nie wysyła żądania API.
