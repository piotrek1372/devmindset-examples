# Uruchomienie

Python 3.12 lub nowszy. Przykłady korzystają wyłącznie z biblioteki standardowej.

`python3 code/15-full.py`

Nazwa urządzenia `koniec` kończy sesję przed pytaniami liczbowymi. Wielkość liter i spacje mają znaczenie. Kwoty wpisuj z kropką; zwykłe skończone liczby. `abc`, pusty tekst, przecinek i niepoprawny int pozostają poza obsługą tej lekcji. Float służy nauce, nie produkcyjnym rozliczeniom.

Code/04-stuck.py jest celową nieskończoną pętlą. Nie uruchamiaj jej bez możliwości zatrzymania; Control C w terminalu przerywa wykonanie. Test uruchamia ją w oddzielnym procesie i zabija po 0,5 s. Code/11-reset-bug.py ma celowy błąd sumowania.

Weryfikacja: `python3 tests/verify.py`. Render wymaga Pillow, FFmpeg i czcionki DejaVu Sans Mono: `python3 render_lesson.py replay.json exports/DevMindset-Python-04-bez-audio.mp4`.
