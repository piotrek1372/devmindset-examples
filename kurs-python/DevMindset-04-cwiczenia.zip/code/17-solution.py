total = 0
count = 0
for number in range(1, 4):
    cost = float(input("Koszt: "))
    if cost < 0:
        continue
    total = total + cost
    count = count + 1
print(f"Przyjęto: {count}")
print(f"Razem: {total:.2f} zł")
