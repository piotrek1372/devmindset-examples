for number in range(3):
    print(f"Naprawa {number}")
print("Koniec")
