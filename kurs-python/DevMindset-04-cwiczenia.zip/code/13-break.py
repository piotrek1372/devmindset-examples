while True:
    device = input("Urządzenie lub koniec: ")
    if device == "koniec":
        break
    print(f"Przyjęto: {device}")
print("Koniec programu")
