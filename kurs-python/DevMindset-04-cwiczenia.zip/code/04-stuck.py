number = 1
while number <= 3:
    number = number
