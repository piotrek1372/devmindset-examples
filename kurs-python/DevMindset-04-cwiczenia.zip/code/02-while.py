number = 1
while number <= 3:
    print(f"Naprawa {number}")
    number = number + 1
print(f"Po pętli: {number}")
