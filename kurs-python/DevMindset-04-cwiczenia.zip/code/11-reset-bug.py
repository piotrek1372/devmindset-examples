total = 0
for number in range(1, 4):
    total = 0
    cost = float(input("Koszt: "))
    total = total + cost
print(f"Razem: {total:.2f} zł")
