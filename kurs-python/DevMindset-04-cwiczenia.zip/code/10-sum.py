total = 0
for number in range(1, 4):
    cost = float(input("Koszt: "))
    total = total + cost
    print(f"Po naprawie {number}: {total:.2f} zł")
print(f"Razem: {total:.2f} zł")
