for number in range(2, 7, 2):
    print(number)
