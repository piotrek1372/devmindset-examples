for number in range(1, 4):
    cost = float(input("Koszt: "))
    if cost < 0:
        continue
    print(f"Przyjęto: {cost:.2f} zł")
print("Koniec trzech prób")
