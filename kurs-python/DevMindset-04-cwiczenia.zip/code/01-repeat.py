print("Sprawdź naprawę 1")
print("Sprawdź naprawę 2")
print("Sprawdź naprawę 3")
