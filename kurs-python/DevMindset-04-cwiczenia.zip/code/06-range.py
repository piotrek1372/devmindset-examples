for number in range(1, 4):
    print(f"Naprawa {number}")
