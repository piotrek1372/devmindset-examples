count = 0
total_cost = 0
while True:
    device = input("Urządzenie lub koniec: ")
    if device == "koniec":
        break
    quantity = int(input("Liczba części: "))
    price = float(input("Cena części: "))
    hours = float(input("Godziny: "))
    rate = float(input("Stawka: "))
    discount = float(input("Rabat kwotowy: "))
    budget = float(input("Budżet: "))
    if quantity < 0 or price < 0 or hours < 0 or rate < 0:
        print("Odrzucono ujemne dane")
        continue
    if budget < 0:
        print("Odrzucono ujemny budżet")
        continue
    subtotal = quantity * price + hours * rate
    if discount < 0 or discount > subtotal:
        print("Odrzucono rabat")
        continue
    cost = subtotal - discount
    print(f"{device}: {cost:.2f} zł")
    if cost <= budget:
        print("W budżecie")
    else:
        print("Ponad budżet")
    count = count + 1
    total_cost = total_cost + cost
print(f"Przyjęte naprawy: {count}")
print(f"Suma wycen: {total_cost:.2f} zł")
