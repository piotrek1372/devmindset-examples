answer = "tak"
while answer == "tak":
    print("Nowa naprawa")
    answer = input("Jeszcze raz? tak/nie: ")
print("Koniec")
