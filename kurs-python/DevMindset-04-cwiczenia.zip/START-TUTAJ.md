# DevMindset — Python od zera, odcinek 4

Pobierz i rozpakuj cały ZIP. Przeczytaj run.md, następnie exercises.md.
Pliki pokazywane w filmie znajdziesz w katalogu code/. 
Na czas samodzielnego kodowania zatrzymaj odtwarzanie filmu. Wznów po wykonaniu zadania. Podpowiedzi są w hints.md, a rozwiązania w solutions.md — zajrzyj tam po własnej próbie.
Niektóre przykłady celowo zawierają błędy; opisuje je lekcja.
