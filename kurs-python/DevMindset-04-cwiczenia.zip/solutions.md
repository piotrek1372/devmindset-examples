# Rozwiązanie

Pełna wersja: code/17-solution.py. Total i count zerujemy przed for. Ujemne dane prowadzą do continue, więc nie docierają do zwiększenia sumy ani licznika. Zakres ma trzy elementy, dlatego zawsze są trzy próby pobrania danych, jeśli konwersja nie zakończy programu wyjątkiem.

Zerowanie count lub total wewnątrz pętli kasuje dotychczasowy wynik. Zwiększanie count przed odrzuceniem danych liczy także ujemne koszty. Zastąpienie continue przez break zakończy całą pętlę przy pierwszej ujemnej wartości, zamiast przejść do kolejnej próby.
