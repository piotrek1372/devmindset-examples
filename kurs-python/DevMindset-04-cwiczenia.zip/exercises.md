# Zadanie samodzielne

Uruchom code/16-task-start.py. Zachowaj trzy próby pobrania kosztu. Pomiń koszty ujemne, ale przyjmuj zero. Dodaj licznik poprawnych kosztów i wypisz go obok sumy.

Sprawdź kolejno:
- 10, -5, 20 → licznik 2, suma 30.
- 0, 0, 0 → licznik 3, suma 0.
- -1, -2, -3 → licznik 0, suma 0.

Wskazówka 1: które wartości trzeba wyzerować tylko raz?
Wskazówka 2: która instrukcja omija resztę bieżącego obrotu?
Wskazówka 3: licznik ma rosnąć tylko na poprawnej ścieżce.

Wyjaśnij: czy program zbiera trzy poprawne koszty, czy wykonuje trzy próby? Dlaczego? Rozwiązanie znajduje się w osobnym pliku solutions.md.
